// Import express module
const express = require('express');
// Create an express application
const app = express();
// Set the port number
const port = 3000;

// Serve static files (CSS, JS, images) from the "public" folder
app.use(express.static('public'));

// Route to render the home page
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html'); // Serve index.html from the public folder
});

// Start the server and listen on the defined port
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
