const mongoose = require("mongoose");
const Model = mongoose.model("trips");

// List all trips
const tripsList = async (req, res) => {
    try {
        const trips = await Model.find({});
        if (!trips || trips.length === 0) {
            return res.status(404).json({ "message": "Trips not found" });
        }
        return res.status(200).json(trips);  // Send the trips as JSON
    } catch (err) {
        return res.status(500).json(err);  // If an error occurs, send a 500 error
    }
};

// Find a trip by its code
const tripsFindCode = async (req, res) => {
    try {
        const trips = await Model.find({ "code": req.params.tripCode });
        if (!trips || trips.length === 0) {
            return res.status(404).json({ "message": "Trip not found" });
        }
        return res.status(200).json(trips);  // Send the trip as JSON
    } catch (err) {
        return res.status(500).json(err);  // If an error occurs, send a 500 error
    }
};

module.exports = {
    tripsList,
    tripsFindCode
};
